package com.studybuzz.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = BuildConfig.STUDY_BUZZ_URL
        if (url.contains("YOUR-STUDY-BUZZ-DOMAIN")) {
            showSetupMessage()
            return
        }
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == Uri.parse(url).host) return false
                if (uri.scheme == "https" || uri.scheme == "mailto") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }
                return true
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) Toast.makeText(this@MainActivity, "Study Buzz server se connect nahi ho pa raha. Internet aur hosting URL check karein.", Toast.LENGTH_LONG).show()
            }
        }
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl(url)
    }

    private fun showSetupMessage() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            setBackgroundColor(Color.rgb(246, 247, 251))
        }
        val title = TextView(this).apply {
            text = "Study Buzz setup required"
            textSize = 24f
            setTextColor(Color.rgb(67, 56, 202))
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "App project ready hai, lekin ise chalane se pehle backend website ko HTTPS par host karein. Phir app/build.gradle.kts mein STUDY_BUZZ_URL ko apne website URL se replace karke APK build karein. SMS OTP ke liye Twilio credentials server par set karna zaroori hai."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        layout.addView(title)
        layout.addView(body)
        setContentView(layout)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }
}
