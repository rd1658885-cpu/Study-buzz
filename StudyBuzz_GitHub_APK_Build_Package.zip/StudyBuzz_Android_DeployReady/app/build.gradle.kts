plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.studybuzz.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.studybuzz.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        // Set with -PstudyBuzzUrl=https://your-real-service.onrender.com
        val studyBuzzUrl = providers.gradleProperty("studyBuzzUrl")
            .orElse("https://YOUR-STUDY-BUZZ-DOMAIN.example")
            .get()
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "STUDY_BUZZ_URL", "\"$studyBuzzUrl\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
