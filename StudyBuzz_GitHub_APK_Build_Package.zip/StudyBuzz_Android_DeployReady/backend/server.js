'use strict';

// Study Buzz: dependency-free Node.js backend. Use HTTPS when deployed publicly.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const https = require('node:https');
const querystring = require('node:querystring');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'study-buzz-db.json');
const JWT_SECRET = process.env.JWT_SECRET || '';
const MAX_BODY = 1024 * 1024;
const TOKEN_TTL_SECONDS = 60 * 60 * 24 * 7;

if (process.env.NODE_ENV === 'production' && JWT_SECRET.length < 32) {
  console.error('ERROR: Set JWT_SECRET to a random secret of at least 32 characters in production.');
  process.exit(1);
}
const signingSecret = JWT_SECRET || crypto.randomBytes(48).toString('hex');
fs.mkdirSync(DATA_DIR, { recursive: true });

function now() { return new Date().toISOString(); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (err, key) => {
    if (err) return reject(err);
    resolve({ salt, hash: key.toString('hex') });
  }));
}
async function checkPassword(password, saved) {
  const candidate = await hashPassword(password, saved.salt);
  return safeEqual(candidate.hash, saved.hash);
}
function initialDb() {
  const courses = [
    { id: 1, title: 'Foundation Mathematics', exam: 'School / Competitive', description: 'A starter sample course for practising core mathematics.', price_rupees: 0, created_at: now() },
    { id: 2, title: 'General Knowledge Basics', exam: 'General Studies', description: 'A free sample course for general awareness and revision.', price_rupees: 0, created_at: now() },
    { id: 3, title: 'English Practice', exam: 'English', description: 'A free sample course for basic English practice.', price_rupees: 0, created_at: now() }
  ];
  return { version: 1, users: [], courses, enrollments: [], doubts: [], nextUserId: 1, nextCourseId: 4, nextDoubtId: 1 };
}
function readDb() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    if (!parsed || !Array.isArray(parsed.users) || !Array.isArray(parsed.courses)) throw new Error('Invalid DB');
    return parsed;
  } catch (e) {
    if (e.code !== 'ENOENT') console.error('Database could not be read; creating a fresh database:', e.message);
    const db = initialDb(); writeDb(db); return db;
  }
}
function writeDb(db) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}
let db = readDb();
const pendingOtpFlows = new Map(); // Short-lived; restart invalidates pending OTP flows.
const OTP_FLOW_TTL_MS = 5 * 60 * 1000;
const OTP_CONFIGURED = Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_VERIFY_SERVICE_SID);
// Optional first-run admin bootstrap. Never hard-code an admin password in source code.
async function bootstrapAdmin() {
  const email = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (!email || !password) return;
  if (password.length < 12) {
    console.error('ADMIN_PASSWORD must be at least 12 characters; admin bootstrap skipped.');
    return;
  }
  if (db.users.some(u => u.email === email)) return;
  const secured = await hashPassword(password);
  db.users.push({ id: db.nextUserId++, name: 'Study Buzz Admin', email, password: secured, role: 'admin', status: 'active', created_at: now() });
  writeDb(db);
  console.log('Initial admin account created for', email);
}

function json(res, status, value, extraHeaders = {}) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...extraHeaders });
  res.end(body);
}
function fail(res, status, error) { return json(res, status, { error }); }
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = ''; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('Request body too large'), { status: 413 })); req.destroy(); return; }
      raw += chunk.toString('utf8');
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function makeToken(user) {
  const head = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ sub: user.id, email: user.email, role: user.role, exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS })).toString('base64url');
  const content = head + '.' + payload;
  const sig = crypto.createHmac('sha256', signingSecret).update(content).digest('base64url');
  return content + '.' + sig;
}
function verifyToken(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  const content = parts[0] + '.' + parts[1];
  const expected = crypto.createHmac('sha256', signingSecret).update(content).digest('base64url');
  if (!safeEqual(parts[2], expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    if (!payload.sub || !payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch { return null; }
}
function publicUser(user) { return { id: user.id, name: user.name, email: user.email, role: user.role, status: user.status, created_at: user.created_at }; }
function getAuth(req) {
  const header = req.headers.authorization || '';
  const match = /^Bearer\s+(.+)$/i.exec(header);
  if (!match) return null;
  const payload = verifyToken(match[1]);
  if (!payload) return null;
  const user = db.users.find(u => u.id === Number(payload.sub));
  if (!user || user.status !== 'active') return null;
  return user;
}
function authRequired(req, res) {
  const user = getAuth(req);
  if (!user) { fail(res, 401, 'Please log in again. Your session may have expired.'); return null; }
  return user;
}
function roleRequired(user, roles, res) {
  if (!roles.includes(user.role)) { fail(res, 403, 'You do not have permission to do this.'); return false; }
  return true;
}
function validEmail(v) { return typeof v === 'string' && v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function normalizePhone(v) {
  const raw = String(v || '').trim();
  const compact = raw.replace(/[\s()-]/g, '');
  if (/^\+91[6-9]\d{9}$/.test(compact)) return compact;
  if (/^[6-9]\d{9}$/.test(compact)) return '+91' + compact;
  return '';
}
function twilioVerify(phone, code) {
  return new Promise((resolve, reject) => {
    if (!OTP_CONFIGURED) return reject(new Error('SMS OTP is not configured. Add Twilio Verify credentials to the hosting environment.'));
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const service = process.env.TWILIO_VERIFY_SERVICE_SID;
    const auth = Buffer.from(sid + ':' + process.env.TWILIO_AUTH_TOKEN).toString('base64');
    const endpoint = code
      ? `/v2/Services/${encodeURIComponent(service)}/VerificationCheck`
      : `/v2/Services/${encodeURIComponent(service)}/Verifications`;
    const form = code ? { To: phone, Code: code } : { To: phone, Channel: 'sms' };
    const data = querystring.stringify(form);
    const req = https.request({ hostname: 'verify.twilio.com', path: endpoint, method: 'POST', headers: {
      Authorization: 'Basic ' + auth, 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(data)
    }, timeout: 12000 }, res => {
      let body = ''; res.setEncoding('utf8'); res.on('data', chunk => body += chunk);
      res.on('end', () => {
        let parsed = {}; try { parsed = JSON.parse(body); } catch {}
        if (res.statusCode < 200 || res.statusCode >= 300) {
          const msg = parsed.message || 'SMS provider rejected the request.';
          return reject(new Error(msg));
        }
        resolve(parsed);
      });
    });
    req.on('timeout', () => req.destroy(new Error('SMS provider timed out. Please try again.')));
    req.on('error', reject); req.end(data);
  });
}
function cleanString(v, max) { return typeof v === 'string' ? v.trim().slice(0, max) : ''; }
function courseView(c) { return { id: c.id, title: c.title, exam: c.exam, description: c.description, price_rupees: c.price_rupees, created_at: c.created_at }; }

const attempts = new Map();
function rateLimit(req, res, key) {
  const ip = req.socket.remoteAddress || 'unknown';
  const k = key + ':' + ip; const t = Date.now();
  let item = attempts.get(k);
  if (!item || t - item.start > 10 * 60 * 1000) item = { start: t, count: 0 };
  item.count++; attempts.set(k, item);
  if (attempts.size > 5000) for (const [id, v] of attempts) if (t - v.start > 10 * 60 * 1000) attempts.delete(id);
  if (item.count > (key === 'auth' ? 20 : 180)) { fail(res, 429, 'Too many requests. Please wait a few minutes and try again.'); return false; }
  return true;
}

async function handleApi(req, res, url) {
  const method = req.method || 'GET';
  const pathname = decodeURIComponent(url.pathname);
  if (pathname.startsWith('/api/auth/') && !rateLimit(req, res, 'auth')) return;

  if (method === 'GET' && pathname === '/api/health') return json(res, 200, { ok: true, service: 'Study Buzz', smsOtpConfigured: OTP_CONFIGURED, time: now() });

  if (method === 'POST' && pathname === '/api/auth/otp/start') {
    const body = await parseBody(req);
    const phone = normalizePhone(body.phone);
    const purpose = body.purpose === 'register' ? 'register' : 'login';
    if (!phone) return fail(res, 400, 'Enter a valid Indian mobile number (10 digits or +91 followed by 10 digits).');
    if (!OTP_CONFIGURED) return fail(res, 503, 'SMS OTP is not configured yet. The owner must add Twilio Verify credentials on the server.');
    if (purpose === 'login') {
      const user = db.users.find(u => u.phone === phone && u.phone_verified && u.status === 'active');
      if (!user) return fail(res, 404, 'No verified account found for this mobile number. Create an account first.');
    } else {
      const email = cleanString(body.email, 254).toLowerCase();
      const name = cleanString(body.name, 80);
      const password = body.password;
      if (name.length < 2) return fail(res, 400, 'Please enter your full name.');
      if (!validEmail(email)) return fail(res, 400, 'Please enter a valid email address.');
      if (typeof password !== 'string' || password.length < 10 || password.length > 128) return fail(res, 400, 'Password must be between 10 and 128 characters.');
      if (db.users.some(u => u.email === email)) return fail(res, 409, 'An account with this email already exists. Please log in.');
      if (db.users.some(u => u.phone === phone)) return fail(res, 409, 'This mobile number is already linked to an account.');
      const secured = await hashPassword(password);
      pendingOtpFlows.set(phone, { purpose, name, email, password: secured, expiresAt: Date.now() + OTP_FLOW_TTL_MS });
    }
    try {
      await twilioVerify(phone);
      if (purpose === 'login') pendingOtpFlows.set(phone, { purpose, expiresAt: Date.now() + OTP_FLOW_TTL_MS });
      return json(res, 200, { message: 'OTP sent if the number is eligible. It expires in about 5 minutes.', phone: phone.slice(0, 3) + '******' + phone.slice(-2) });
    } catch (err) {
      if (purpose === 'register') pendingOtpFlows.delete(phone);
      return fail(res, 502, 'Could not send SMS OTP: ' + err.message);
    }
  }
  if (method === 'POST' && pathname === '/api/auth/otp/verify') {
    const body = await parseBody(req);
    const phone = normalizePhone(body.phone);
    const code = String(body.code || '').trim();
    if (!phone || !/^\d{4,10}$/.test(code)) return fail(res, 400, 'Enter the mobile number and OTP code you received.');
    const pending = pendingOtpFlows.get(phone);
    if (!pending || pending.expiresAt < Date.now()) { pendingOtpFlows.delete(phone); return fail(res, 400, 'OTP session expired. Request a new OTP.'); }
    try {
      const checked = await twilioVerify(phone, code);
      if (checked.status !== 'approved') return fail(res, 401, 'Incorrect or expired OTP. Please try again.');
      pendingOtpFlows.delete(phone);
      let user;
      if (pending.purpose === 'register') {
        if (db.users.some(u => u.email === pending.email || u.phone === phone)) return fail(res, 409, 'Email or mobile number is already registered. Please log in.');
        user = { id: db.nextUserId++, name: pending.name, email: pending.email, phone, phone_verified: true, password: pending.password, role: 'student', status: 'active', created_at: now() };
        db.users.push(user); writeDb(db);
      } else {
        user = db.users.find(u => u.phone === phone && u.phone_verified && u.status === 'active');
        if (!user) return fail(res, 401, 'No active verified account was found.');
      }
      return json(res, 200, { token: makeToken(user), user: publicUser(user), message: pending.purpose === 'register' ? 'Mobile verified and account created.' : 'Logged in successfully with SMS OTP.' });
    } catch (err) {
      return fail(res, 502, 'Could not verify OTP: ' + err.message);
    }
  }

  if (method === 'POST' && pathname === '/api/auth/register') {
    const body = await parseBody(req);
    const name = cleanString(body.name, 80); const email = cleanString(body.email, 254).toLowerCase(); const password = body.password;
    if (name.length < 2) return fail(res, 400, 'Please enter your full name (at least 2 characters).');
    if (!validEmail(email)) return fail(res, 400, 'Please enter a valid email address.');
    if (typeof password !== 'string' || password.length < 10 || password.length > 128) return fail(res, 400, 'Password must be between 10 and 128 characters.');
    if (db.users.some(u => u.email === email)) return fail(res, 409, 'An account with this email already exists. Please log in.');
    const secured = await hashPassword(password);
    const user = { id: db.nextUserId++, name, email, password: secured, role: 'student', status: 'active', created_at: now() };
    db.users.push(user); writeDb(db);
    return json(res, 201, { token: makeToken(user), user: publicUser(user) });
  }
  if (method === 'POST' && pathname === '/api/auth/login') {
    const body = await parseBody(req); const email = cleanString(body.email, 254).toLowerCase(); const password = body.password;
    if (!validEmail(email) || typeof password !== 'string') return fail(res, 400, 'Enter your email address and password.');
    const user = db.users.find(u => u.email === email);
    // Keep the error generic to avoid exposing whether an email is registered.
    if (!user || !(await checkPassword(password, user.password))) return fail(res, 401, 'Email or password is incorrect.');
    if (user.status !== 'active') return fail(res, 403, 'This account is not active. Please contact the administrator.');
    return json(res, 200, { token: makeToken(user), user: publicUser(user) });
  }

  if (method === 'GET' && pathname === '/api/courses') return json(res, 200, { courses: db.courses.slice().sort((a,b) => a.id-b.id).map(courseView) });
  if (method === 'GET' && pathname === '/api/me') {
    const user = authRequired(req, res); if (!user) return;
    return json(res, 200, { user: publicUser(user) });
  }
  if (method === 'POST' && pathname === '/api/courses') {
    const user = authRequired(req, res); if (!user || !roleRequired(user, ['teacher', 'admin'], res)) return;
    const body = await parseBody(req); const title = cleanString(body.title, 120); const exam = cleanString(body.exam, 80) || 'General'; const description = cleanString(body.description, 2000);
    const price = Number(body.price_rupees);
    if (title.length < 3) return fail(res, 400, 'Course title must be at least 3 characters.');
    if (!Number.isSafeInteger(price) || price < 0 || price > 1000000) return fail(res, 400, 'Enter a valid price between ₹0 and ₹10,00,000.');
    const course = { id: db.nextCourseId++, title, exam, description, price_rupees: price, created_at: now(), created_by: user.id };
    db.courses.push(course); writeDb(db); return json(res, 201, { course: courseView(course) });
  }
  let m = pathname.match(/^\/api\/courses\/(\d+)\/enroll$/);
  if (method === 'POST' && m) {
    const user = authRequired(req, res); if (!user) return;
    if (user.role !== 'student') return fail(res, 403, 'Only student accounts can enrol in courses.');
    const id = Number(m[1]); const course = db.courses.find(c => c.id === id);
    if (!course) return fail(res, 404, 'Course not found.');
    if (course.price_rupees > 0) return fail(res, 402, 'This course is paid. Payment processing is not configured yet.');
    if (db.enrollments.some(e => e.user_id === user.id && e.course_id === id)) return json(res, 200, { message: 'You are already enrolled in this course.' });
    db.enrollments.push({ user_id: user.id, course_id: id, created_at: now() }); writeDb(db);
    return json(res, 201, { message: 'Enrolled successfully.' });
  }
  if (method === 'GET' && pathname === '/api/my-courses') {
    const user = authRequired(req, res); if (!user) return;
    const ids = db.enrollments.filter(e => e.user_id === user.id).map(e => e.course_id);
    return json(res, 200, { courses: db.courses.filter(c => ids.includes(c.id)).map(courseView) });
  }
  if (method === 'POST' && pathname === '/api/doubts') {
    const user = authRequired(req, res); if (!user) return;
    if (user.role !== 'student') return fail(res, 403, 'Only students can submit doubts.');
    const body = await parseBody(req); const question = cleanString(body.question, 4000);
    if (question.length < 5) return fail(res, 400, 'Please enter a question with at least 5 characters.');
    db.doubts.push({ id: db.nextDoubtId++, user_id: user.id, student_name: user.name, question, answer: '', answered_by: null, created_at: now(), answered_at: null }); writeDb(db);
    return json(res, 201, { message: 'Doubt submitted.' });
  }
  if (method === 'GET' && pathname === '/api/doubts') {
    const user = authRequired(req, res); if (!user) return;
    const doubts = user.role === 'student' ? db.doubts.filter(d => d.user_id === user.id) : (['teacher','admin'].includes(user.role) ? db.doubts : null);
    if (!doubts) return fail(res, 403, 'You do not have permission to view doubts.');
    return json(res, 200, { doubts: doubts.slice().sort((a,b) => b.id-a.id).map(d => ({ id:d.id, student_name:d.student_name, question:d.question, answer:d.answer, created_at:d.created_at, answered_at:d.answered_at })) });
  }
  m = pathname.match(/^\/api\/doubts\/(\d+)\/answer$/);
  if (method === 'POST' && m) {
    const user = authRequired(req, res); if (!user || !roleRequired(user, ['teacher','admin'], res)) return;
    const body = await parseBody(req); const answer = cleanString(body.answer, 4000);
    if (answer.length < 2) return fail(res, 400, 'Reply must contain at least 2 characters.');
    const doubt = db.doubts.find(d => d.id === Number(m[1])); if (!doubt) return fail(res, 404, 'Doubt not found.');
    doubt.answer = answer; doubt.answered_by = user.id; doubt.answered_at = now(); writeDb(db);
    return json(res, 200, { message: 'Reply saved.' });
  }
  if (method === 'GET' && pathname === '/api/admin/summary') {
    const user = authRequired(req, res); if (!user || !roleRequired(user, ['admin'], res)) return;
    return json(res, 200, { students:db.users.filter(u=>u.role==='student').length, teachers:db.users.filter(u=>u.role==='teacher').length, courses:db.courses.length, enrollments:db.enrollments.length, unanswered_doubts:db.doubts.filter(d=>!d.answer).length });
  }
  if (method === 'GET' && pathname === '/api/admin/users') {
    const user = authRequired(req, res); if (!user || !roleRequired(user, ['admin'], res)) return;
    return json(res, 200, { users:db.users.map(u=>({ id:u.id, name:u.name, email:u.email, role:u.role, status:u.status, created_at:u.created_at })) });
  }
  m = pathname.match(/^\/api\/admin\/users\/(\d+)\/(role|status)$/);
  if (method === 'POST' && m) {
    const user = authRequired(req, res); if (!user || !roleRequired(user, ['admin'], res)) return;
    const target = db.users.find(u => u.id === Number(m[1])); if (!target) return fail(res, 404, 'User not found.');
    const body = await parseBody(req);
    if (m[2] === 'role') {
      if (!['student','teacher','admin'].includes(body.role)) return fail(res, 400, 'Invalid role.');
      if (target.id === user.id && body.role !== 'admin') return fail(res, 400, 'You cannot remove your own admin role.');
      target.role = body.role;
    } else {
      if (!['active','pending','suspended'].includes(body.status)) return fail(res, 400, 'Invalid status.');
      if (target.id === user.id && body.status !== 'active') return fail(res, 400, 'You cannot suspend your own account.');
      target.status = body.status;
    }
    writeDb(db); return json(res, 200, { message: 'User updated.' });
  }
  return fail(res, 404, 'API route not found.');
}

const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.ico':'image/x-icon' };
function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === '/') pathname = '/index.html';
  const file = path.resolve(PUBLIC, '.' + pathname);
  if (!file.startsWith(PUBLIC + path.sep) && file !== path.join(PUBLIC, 'index.html')) return fail(res, 403, 'Forbidden.');
  fs.readFile(file, (err, data) => {
    if (err) return fail(res, 404, 'File not found.');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options':'nosniff', 'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'", 'Referrer-Policy':'strict-origin-when-cross-origin' });
    res.end(data);
  });
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'Allow':'GET,POST,OPTIONS' }); return res.end(); }
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return fail(res, 405, 'Method not allowed.');
    return serveStatic(req, res, url);
  } catch (err) {
    console.error('Request error:', err.message);
    if (!res.headersSent) fail(res, err.status || 500, err.status ? err.message : 'Server error. Please try again.');
    else res.end();
  }
});
bootstrapAdmin().then(() => server.listen(PORT, HOST, () => {
  console.log(`Study Buzz running at http://localhost:${PORT}`);
  console.log(`Database file: ${DB_FILE}`);
  if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) console.log('Admin bootstrap not configured. Set ADMIN_EMAIL and ADMIN_PASSWORD before public deployment.');
})).catch(err => { console.error('Startup failed:', err); process.exit(1); });
