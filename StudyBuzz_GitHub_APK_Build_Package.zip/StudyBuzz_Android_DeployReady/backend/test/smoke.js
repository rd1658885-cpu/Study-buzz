'use strict';
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');

(async () => {
  const port = 3200 + Math.floor(Math.random() * 1000);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'study-buzz-test-'));
  const child = spawn(process.execPath, ['server.js'], {
    cwd: path.resolve(__dirname, '..'),
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDir, NODE_ENV: 'test', JWT_SECRET: 'test-secret-that-is-long-enough-for-smoke-tests' },
    stdio: 'ignore'
  });
  const base = `http://127.0.0.1:${port}`;
  try {
    let health;
    for (let i = 0; i < 40; i++) {
      try { const r = await fetch(base + '/api/health'); if (r.ok) { health = await r.json(); break; } } catch {}
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    assert.equal(health?.ok, true, 'health endpoint should respond');
    assert.equal(health?.smsOtpConfigured, false, 'OTP must report unconfigured without provider credentials');
    const coursesResponse = await fetch(base + '/api/courses');
    assert.equal(coursesResponse.status, 200);
    const courses = await coursesResponse.json();
    assert.ok(courses.courses.length >= 3, 'sample courses should be seeded');
    const otpResponse = await fetch(base + '/api/auth/otp/start', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ phone: '9876543210', purpose: 'login' }) });
    assert.equal(otpResponse.status, 503, 'OTP endpoint should clearly refuse to pretend SMS was sent without configuration');
    const otpError = await otpResponse.json();
    assert.match(otpError.error, /not configured/i);
    console.log('PASS: health, course listing, and safe OTP-not-configured response');
  } finally {
    child.kill('SIGTERM');
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
})().catch(err => { console.error(err); process.exitCode = 1; });
